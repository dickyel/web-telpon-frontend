<a href="http://www.agilecarousel.com/">Agile Carousel - JQuery Carousel / Slideshow Plugin</a>
=============

<a href="http://www.agilecarousel.com/">Agile Carousel</a> is a JQuery Plugin that allows you to create a slideshow or carosuel.<br>
Highly customizable so you can build according to your requirements. JSON data format is used.<br><br>
<strong>See full documentation at <a href="http://www.agilecarousel.com/">www.agilecarousel.com</a>!</strong>

<a href="http://www.agilecarousel.com/">View Examples</a>
=============


<a href="http://agilecarousel.com/">![View Slideshow Examples](http://agilecarousel.com/images/viewExamplesBanner.jpg "View Slideshow Examples")</a>
