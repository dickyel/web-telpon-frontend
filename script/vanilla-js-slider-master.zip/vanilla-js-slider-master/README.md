# Vanilla JS Slider
Simple slider created with pure javascript, html and css
